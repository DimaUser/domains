<?php
function diskriminant($a,$b,$c)
{
    return $b ** 2 - 4 * $a * $c;
}
