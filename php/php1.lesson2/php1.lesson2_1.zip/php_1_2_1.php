<html>
<body>
<h3>
    Логические функции "И" "ИЛИ" "Исключающее ИЛИ"
</h3>
<?php
function andand($x,$y)
{
    return $x&&$y;
}
?>
    <table border="1">
        <caption>Таблица истинности функции И</caption>
        <tr>
            <th>a</th>
            <th>b</th>
            <th>a & b</th>

        </tr>
        <tr><td>0</td><td>0</td>
            <td>
                <?php
                echo (int)andand(0,0);
                ?>
            </td></tr>
        <tr><td>0</td><td>1</td>
            <td>
                <?php
                echo (int)andand(0,1);
                ?>
            </td></tr>
        <tr><td>1</td><td>0</td>
            <td>
                <?php
                echo (int)andand(1,0);
                ?>
            </td></tr>
        <tr><td>1</td><td>1</td>
            <td>
                <?php
                echo (int)andand(1,1);
                ?>
            </td></tr>
    </table>
<?php
function oror($x,$y)
{
    return $x||$y;
}
?>
<table border="1">
    <caption>Таблица истинности функции ИЛИ</caption>
    <tr>
        <th>a</th>
        <th>b</th>
        <th>a || b</th>

    </tr>
    <tr><td>0</td><td>0</td>
        <td>
            <?php
            echo (int)oror(0,0);
            ?>
        </td></tr>
    <tr><td>0</td><td>1</td>
        <td>
            <?php
            echo (int)oror(0,1);
            ?>
        </td></tr>
    <tr><td>1</td><td>0</td>
        <td>
            <?php
            echo (int)oror(1,0);
            ?>
        </td></tr>
    <tr><td>1</td><td>1</td>
        <td>
            <?php
            echo (int)oror(1,1);
            ?>
        </td></tr>
  </table>
<?php
function xorxor($x,$y)
{
    return $x XOR $y;
}
?>
<table border="1">
    <caption>Таблица истинности функции Исключающее ИЛИ</caption>
    <tr>
        <th>a</th>
        <th>b</th>
        <th>a XOR b</th>

    </tr>
    <tr><td>0</td><td>0</td>
        <td>
            <?php
            echo (int)xorxor(0,0);
            ?>
        </td></tr>
    <tr><td>0</td><td>1</td>
        <td>
            <?php
            echo (int)xorxor(0,1);
            ?>
        </td></tr>
    <tr><td>1</td><td>0</td>
        <td>
            <?php
            echo (int)xorxor(1,0);
            ?>
        </td></tr>
    <tr><td>1</td><td>1</td>
        <td>
            <?php
            echo (int)xorxor(1,1);
            ?>
        </td></tr>
</table>
</body>
</html>