<?php
function diskriminant($a,$b,$c)
{
    return $b**2-4*$a*$c;
}
function x1($a,$b,$c)
{
    if (diskriminant($a,$b,$c)>=0)
    {
        return (-$b+diskriminant($a,$b,$c)**0.5)/(2*$a);}
    else
        return 'Значение не существует';

}
function x2($a,$b,$c)
{
    if (diskriminant($a,$b,$c)>=0)
    {
        return (-$b-diskriminant($a,$b,$c)**0.5)/(2*$a);}
    else
        return 'Значение не существует';

}
?>
